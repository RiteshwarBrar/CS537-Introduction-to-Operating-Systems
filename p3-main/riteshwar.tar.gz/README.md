Name: Riteshwar Singh Brar
CS Login: riteshwar
Email: rbrar@wisc.edu
Status of implementation: Works just fine and passes all tests

citations: learned about piping from: https://www.geeksforgeeks.org/pipe-system-call/
